# 典型案例数据导入说明

## 导出信息

- 导出时间: 2026-06-15T11:09:06.078801
- 源数据库: `asset_allocation`
- 导出集合: 40 个
- 导出记录: 6,731 条

## 使用 mongoimport 导入

```bash
# 逐个导入
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection subject_risk_records --file subject_risk_records.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection subject_risk_import_batches --file subject_risk_import_batches.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection zysc_ptl_info_records --file zysc_ptl_info_records.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection zysc_ptl_info_import_batches --file zysc_ptl_info_import_batches.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection zysc_ptl_holder_records --file zysc_ptl_holder_records.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection zysc_ptl_holder_import_batches --file zysc_ptl_holder_import_batches.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ptl_ast_hld --file dwd_ptl_ast_hld.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ast_info --file dwd_ast_info.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_isr_institution --file dwd_isr_institution.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_isr_institution_finance --file dwd_isr_institution_finance.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ptl_info --file dwd_ptl_info.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ast_yield_info --file dwd_ast_yield_info.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_rsk_sentiment --file dwd_rsk_sentiment.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_rsk_credit --file dwd_rsk_credit.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_rsk_credit_position --file dwd_rsk_credit_position.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_crdt_agme_info --file dwd_crdt_agme_info.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ast_fiveclass --file dwd_ast_fiveclass.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_val_summary --file dwd_val_summary.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_mkt_bond --file dwd_mkt_bond.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_mkt_bond_creditrating --file dwd_mkt_bond_creditrating.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_mkt_bond_ecl --file dwd_mkt_bond_ecl.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_mkt_bond_duration --file dwd_mkt_bond_duration.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_mkt_bond_issue --file dwd_mkt_bond_issue.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_mkt_bond_market --file dwd_mkt_bond_market.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_mkt_bond_amount --file dwd_mkt_bond_amount.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_mkt_stock --file dwd_mkt_stock.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_mkt_stock_yield --file dwd_mkt_stock_yield.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection tag_ptl_info --file tag_ptl_info.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ptl_asset_config_info --file dwd_ptl_asset_config_info.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ptl_managers --file dwd_ptl_managers.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ptl_manager --file dwd_ptl_manager.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ast_fund_manager --file dwd_ast_fund_manager.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ptl_nav --file dwd_ptl_nav.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ptl_attribution --file dwd_ptl_attribution.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection dwd_ptl_risk --file dwd_ptl_risk.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection lineage_nodes --file lineage_nodes.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection lineage_edges --file lineage_edges.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection semantic_stats_profiles --file semantic_stats_profiles.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection semantic_domain_macro --file semantic_domain_macro.jsonl --mode upsert --upsertFields _id
mongoimport --uri 'mongodb://localhost:27017/asset_allocation' --collection profile_dynamic_stats --file profile_dynamic_stats.jsonl --mode upsert --upsertFields _id
```

## 使用 Python pymongo 导入

```python
from pymongo import MongoClient
from bson import json_util

client = MongoClient('mongodb://目标地址:27017')
db = client['asset_allocation']

collections = [
    'subject_risk_records',
    'subject_risk_import_batches',
    'zysc_ptl_info_records',
    'zysc_ptl_info_import_batches',
    'zysc_ptl_holder_records',
    'zysc_ptl_holder_import_batches',
    'dwd_ptl_ast_hld',
    'dwd_ast_info',
    'dwd_isr_institution',
    'dwd_isr_institution_finance',
    'dwd_ptl_info',
    'dwd_ast_yield_info',
    'dwd_rsk_sentiment',
    'dwd_rsk_credit',
    'dwd_rsk_credit_position',
    'dwd_crdt_agme_info',
    'dwd_ast_fiveclass',
    'dwd_val_summary',
    'dwd_mkt_bond',
    'dwd_mkt_bond_creditrating',
    'dwd_mkt_bond_ecl',
    'dwd_mkt_bond_duration',
    'dwd_mkt_bond_issue',
    'dwd_mkt_bond_market',
    'dwd_mkt_bond_amount',
    'dwd_mkt_stock',
    'dwd_mkt_stock_yield',
    'tag_ptl_info',
    'dwd_ptl_asset_config_info',
    'dwd_ptl_managers',
    'dwd_ptl_manager',
    'dwd_ast_fund_manager',
    'dwd_ptl_nav',
    'dwd_ptl_attribution',
    'dwd_ptl_risk',
    'lineage_nodes',
    'lineage_edges',
    'semantic_stats_profiles',
    'semantic_domain_macro',
    'profile_dynamic_stats',
]

for coll_name in collections:
    with open(f'{coll_name}.jsonl', 'r', encoding='utf-8') as f:
        docs = [json_util.loads(line) for line in f if line.strip()]
    if docs:
        from pymongo import UpdateOne
        ops = [UpdateOne({'_id': d['_id']}, {'$set': d}, upsert=True) for d in docs]
        db[coll_name].bulk_write(ops)
        print(f'{coll_name}: {len(docs)} 条导入完成')
```
